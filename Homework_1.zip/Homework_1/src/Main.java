import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String work;                       // Задание №1
        final int NUM = 365;               // Задание №2
        String word = "Days in Year";      // Задание №3
        work = NUM + " " + word;           // Задание №4
        System.out.println(work);          // Задание №5

        if (NUM < 0) {                     // Задание №6
            System.out.println("let's go travel");

        } else if (NUM > 0) {
            System.out.println("Good Day");
        } else {
            System.out.println("Good Work");
        }
        System.out.print("“Введите ваше имя:");
        Scanner in = new Scanner(System.in);
        String name = in.nextLine();
        System.out.print("Приветствую тебя" + name);


    }
}


